export {};
//# sourceMappingURL=moment-plugin.d.ts.map