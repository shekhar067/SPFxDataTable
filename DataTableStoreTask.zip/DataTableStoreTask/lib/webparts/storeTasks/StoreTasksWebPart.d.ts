import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
import 'datatables.net';
import 'moment';
export interface IStoreTasksWebPartProps {
    listName: string;
}
export default class StoreTasksWebPart extends BaseClientSideWebPart<IStoreTasksWebPartProps> {
    private _isDarkTheme;
    private _environmentMessage;
    protected onInit(): Promise<void>;
    render(): void;
    private _getEnvironmentMessage;
    protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
    protected get disableReactivePropertyChanges(): boolean;
}
//# sourceMappingURL=StoreTasksWebPart.d.ts.map