import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
import { escape } from '@microsoft/sp-lodash-subset';
//import './moment-plugin';

require('./moment-plugin');
import styles from './StoreTasksWebPart.module.scss';
import * as strings from 'StoreTasksWebPartStrings';

import 'datatables.net';
import 'moment';


export interface IStoreTasksWebPartProps {
  listName: string;
}
import * as $ from 'jquery';
export default class StoreTasksWebPart extends BaseClientSideWebPart<IStoreTasksWebPartProps> {

  private _isDarkTheme: boolean = false;
  private _environmentMessage: string = '';

  protected onInit(): Promise<void> {
    this._environmentMessage = this._getEnvironmentMessage();

    return super.onInit();
  }


  public render(): void {
    this.domElement.innerHTML = `
        <table>
          <tr>
            <td><label for="start">Start date:</label></td>

            <td>From : <input type="date" id="StartSDate" name="trip-start" placeholder="dd-mm-yyyy" value=""
                min="1997-01-01" max="2030-12-31"></td>

            <td>To : <input type="date" id="StartEDate" name="trip-start" placeholder="dd-mm-yyyy" value=""
                min="1997-01-01" max="2030-12-31"></td>
            <td></td>
          </tr>
          <tr>
            <td><label for="start">Due date:</label></td>

            <td>From : <input type="date" id="DueSDate" name="trip-start" placeholder="dd-mm-yyyy" value=""
                min="1997-01-01" max="2030-12-31"></td>

            <td>To : <input type="date" id="DueEDate" name="trip-start" placeholder="dd-mm-yyyy" value=""
                min="1997-01-01" max="2030-12-31"></td>
            <td>

              <input type="button" value="Apply Date Filter" id="btnDFilter" />
              <input type="button" value="Clear Filter" id="btnClrFilter" /></td>
          </tr>
          <tr><td colspan="3"><button id="btnExport">Export</button></td></tr>
          <table>

          <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" />
          <table id="dataTable" class="display ${styles.storeTasks}" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Start Date</th>
                <th>Due Date</th>
                <th>Labour Impact</th>
                <th>Budgeted Hours</th>
              </tr>
            </thead>
          </table>`;

    $(document).ready(() => {
      $('#dataTable', this.domElement).DataTable({

        'ajax': {
          'url': `../../_api/web/lists/getbytitle('${escape(this.properties.listName)}')/items?$select=*`,
          'headers': { 'Accept': 'application/json;odata=nometadata' },
          'dataSrc': function (data) {
            return data.value.map(function (item) {
              return [
                item.ID,
                item.Title,
                new Date(item.field_1), //Start Date
                new Date(item.field_2), //Due Date
                item.field_10, //Labour Impact
                item.field_7 //Task_x0020_Categories
              ];
            });
          }
        },

        columnDefs: [{
          targets: [2, 3],
          render: ($.fn.dataTable.render as any).moment('MM/DD/YYYY')
          /* render: function (data) {
             var dt = new Date(data);
             return (dt.getMonth() + 1) + "/" + dt.getDate() + "/" + dt.getFullYear();
           }*/
        }]
      });
      var table = $('#dataTable').DataTable();




      $(function () {

        $("#btnExport").click(function (e) {
          table.page.len(-1).draw();
          window.open('data:application/vnd.ms-excel,' +
            encodeURIComponent($('#dataTable').parent().html()));
          setTimeout(function () {
            table.page.len(10).draw();
          }, 1000)

        });
      });



      // Event listener to the two range filtering inputs to redraw on input
      $('#StartSDate, #StartEDate,#DueSDate,#DueEDate').keyup(function () {
        table.draw();
      });
      $('#StartSDate, #StartEDate,#DueSDate,#DueEDate').change(function () {
        table.draw();
      });

      $('#btnDFilter,#btnSFilter').click(function () {
        table.draw();
      });
      $('#btnClrFilter').click(function () {
        $('#StartSDate').val('');
        $('#StartEDate').val('');
        $('#DueSDate').val('');
        $('#DueEDate').val('');
        table.draw();
      });
      $.extend($.fn.dataTable.defaults, {
        responsive: true
      });

      $.fn.dataTable.ext.search.push(function (settings, data, dataIndex) {
        var SDate1 = $('#StartSDate').val();
        var SDate2 = $('#StartEDate').val();
        var dDate1 = $('#DueSDate').val();
        var dDate2 = $('#DueEDate').val();
        var sDate = data[2]; // use data for the age column
        var dDate = data[3];
        debugger;
        if (SDate1 != '' && SDate2 != '' && dDate1 != "" && dDate2 != "") {
          if ((new Date(SDate1) <= new Date(sDate) && new Date(sDate) <= new Date(SDate2) && (new Date(dDate1) <= new Date(dDate) && new Date(dDate) <= new Date(dDate2)))) {
            return true;
          }
        }
        else if (SDate1 != '' && SDate2 != '') {
          if ((new Date(SDate1) <= new Date(sDate) && new Date(sDate) <= new Date(SDate2))) {
            return true;
          }
        }
        else if (dDate1 != "" && dDate2 != "") {
          if ((new Date(dDate1) <= new Date(dDate) && new Date(dDate) <= new Date(dDate2))) {
            return true;
          }
        }
        else {
          return true;
        }
        return false;
      });
    });
  }

  private _getEnvironmentMessage(): string {
    if (!!this.context.sdks.microsoftTeams) { // running in Teams
      return this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentTeams : strings.AppTeamsTabEnvironment;
    }
    return this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentSharePoint : strings.AppSharePointEnvironment;
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) {
      return;
    }
    this._isDarkTheme = !!currentTheme.isInverted;
    const {
      semanticColors
    } = currentTheme;
    this.domElement.style.setProperty('--bodyText', semanticColors.bodyText);
    this.domElement.style.setProperty('--link', semanticColors.link);
    this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered);

  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [{
        header: {
          description: strings.PropertyPaneDescription
        },
        groups: [{
          groupName: strings.BasicGroupName,
          groupFields: [
            PropertyPaneTextField('listName', {
              label: strings.ListNameFieldLabel
            })
          ]
        }]
      }]
    };
  }

  protected get disableReactivePropertyChanges(): boolean {
    return true;
  }
}
