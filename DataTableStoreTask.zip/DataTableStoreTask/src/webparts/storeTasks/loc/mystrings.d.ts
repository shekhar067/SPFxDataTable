declare interface IStoreTasksWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  AppLocalEnvironmentSharePoint: string;
  AppLocalEnvironmentTeams: string;
  AppSharePointEnvironment: string;
  AppTeamsTabEnvironment: string;
  ListNameFieldLabel: string;
}

declare module 'StoreTasksWebPartStrings' {
  const strings: IStoreTasksWebPartStrings;
  export = strings;
}
